void deleteTree(TreeNode *root) {

    if(root != NULL) {
      deleteTree(root->right);
       deleteTree(root->left);
       delete root;
   }
}

